package com.ultron.ai

import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Step 3: the AI brain — now using Google's Gemini API (free tier available
 * from Google AI Studio, no card needed to start).
 *
 * When CommandRouter's rule-based patterns (Step 2) don't match a command,
 * it comes here. We send it to Gemini with instructions to reply with ONE
 * small JSON action, then CommandRouter runs that action using the same
 * automation primitives from Step 2 (open/click/type/back/home).
 */
object AiBrain {

    private const val MODEL = "gemini-2.0-flash"
    private fun apiUrl(apiKey: String) =
        "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$apiKey"

    private const val SYSTEM_PROMPT = """
You are the command-interpreter brain for "Ultron", an Android on-device
assistant. The user will type a short instruction in Hindi, English, or a
mix of both. Convert it into exactly ONE JSON object (nothing else, no
markdown fences, no explanation) describing the single action to perform:

{"action": "open", "value": "<app name>"}
{"action": "click", "value": "<visible text of the button/link to tap>"}
{"action": "type", "value": "<text to type into the focused field>"}
{"action": "back"}
{"action": "home"}
{"action": "recents"}
{"action": "speak", "value": "<a short reply, when the user is just chatting and no phone action is needed>"}

Pick the single best matching action. Reply with ONLY the raw JSON object.
"""

    /**
     * Calls the Gemini API on a background thread and delivers the parsed
     * action back on [onResult]. [onResult] is called on the SAME background
     * thread — the caller is responsible for hopping back to the main thread
     * before touching any UI.
     */
    fun interpret(command: String, apiKey: String, onResult: (action: String, value: String?) -> Unit, onError: (String) -> Unit) {
        Thread {
            try {
                val url = URL(apiUrl(apiKey))
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("content-type", "application/json")
                conn.doOutput = true

                val body = JSONObject().apply {
                    put("system_instruction", JSONObject().apply {
                        put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT)))
                    })
                    put("contents", JSONArray().put(
                        JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().put(JSONObject().put("text", command)))
                        }
                    ))
                }

                val os: OutputStream = conn.outputStream
                os.write(body.toString().toByteArray(Charsets.UTF_8))
                os.close()

                val code = conn.responseCode
                if (code !in 200..299) {
                    val err = conn.errorStream?.bufferedReader()?.readText() ?: "HTTP $code"
                    onError("AI se baat nahi ho payi: $err")
                    return@Thread
                }

                val responseText = conn.inputStream.bufferedReader().readText()
                val json = JSONObject(responseText)
                val text = json.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                    .trim()

                val cleaned = text.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                val actionJson = JSONObject(cleaned)
                val action = actionJson.getString("action")
                val value = if (actionJson.has("value")) actionJson.getString("value") else null

                onResult(action, value)
            } catch (e: Exception) {
                onError("AI brain me dikkat aayi: ${e.message}")
            }
        }.start()
    }
}
