package com.ultron.ai

import android.content.Context

/**
 * Step 2 rule-based patterns are tried first (instant, no network, no cost).
 * Anything that doesn't match falls through to Step 3's AiBrain, which asks
 * Claude to turn the free-form command into one of the same actions.
 */
object CommandRouter {

    /** [onResult] is called with the reply to show/speak. May be called
     *  on a background thread (when the AI brain was used) — the caller
     *  must hop back to the main thread before touching any UI. */
    fun handle(context: Context, rawCommand: String, onResult: (String) -> Unit) {
        val service = UltronAccessibilityService.instance
        if (service == null) {
            onResult("Accessibility permission on nahi hai. Settings me jaake Ultron ko ON karo.")
            return
        }

        val ruleBasedResult = tryRuleBased(service, rawCommand)
        if (ruleBasedResult != null) {
            onResult(ruleBasedResult)
            return
        }

        val apiKey = ApiKeyStore.get(context)
        if (apiKey.isNullOrBlank()) {
            onResult(
                "Yeh command samajh nahi paya. AI brain use karne ke liye MainActivity " +
                "me apni Claude API key daalo (Step 3 setup)."
            )
            return
        }

        AiBrain.interpret(
            command = rawCommand,
            apiKey = apiKey,
            onResult = { action, value -> onResult(execute(service, action, value)) },
            onError = { onResult(it) }
        )
    }

    /** Returns a response if a fixed pattern matched, or null to fall through to AI. */
    private fun tryRuleBased(service: UltronAccessibilityService, rawCommand: String): String? {
        val cmd = rawCommand.trim().lowercase()
        return when {
            cmd == "back" || cmd.contains("wapas jao") -> execute(service, "back", null)
            cmd == "home" || cmd.contains("home jao") -> execute(service, "home", null)
            cmd == "recents" || cmd.contains("recent apps") -> execute(service, "recents", null)
            cmd.startsWith("open ") || cmd.startsWith("khol ") ->
                execute(service, "open", rawCommand.trim().substringAfter(" ").trim())
            cmd.startsWith("click ") || cmd.startsWith("tap ") || cmd.startsWith("dabao ") ->
                execute(service, "click", rawCommand.trim().substringAfter(" ").trim())
            cmd.startsWith("type ") || cmd.startsWith("likho ") ->
                execute(service, "type", rawCommand.trim().substringAfter(" ").trim())
            else -> null
        }
    }

    /** Shared by both the rule-based path and the AI-brain path, so both
     *  ultimately call the same automation primitives the same way. */
    private fun execute(service: UltronAccessibilityService, action: String, value: String?): String {
        return when (action) {
            "back" -> if (service.pressBack()) "Theek hai, back ja raha hoon" else "Back nahi kar paya"
            "home" -> if (service.pressHome()) "Home screen par ja raha hoon" else "Home nahi kar paya"
            "recents" -> if (service.openRecents()) "Recent apps khol raha hoon" else "Recents nahi khul paya"
            "open" -> {
                val app = value ?: return "Kaunsa app, yeh nahi bataya"
                if (service.openApp(app)) "$app khol raha hoon" else "'$app' naam ka app nahi mila"
            }
            "click" -> {
                val label = value ?: return "Kis par click karna hai, yeh nahi bataya"
                if (service.clickByText(label)) "'$label' par tap kar diya" else "'$label' screen par nahi dikha"
            }
            "type" -> {
                val text = value ?: return "Kya type karna hai, yeh nahi bataya"
                if (service.typeIntoFocused(text)) "Type kar diya: $text" else "Koi text box focus me nahi hai"
            }
            "speak" -> value ?: "Ji boss?"
            else -> "Yeh action samajh nahi paya: $action"
        }
    }
}
