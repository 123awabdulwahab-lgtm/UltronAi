# Ultron AI — Step 1 + 2 + 3 + 4 (Voice)

Android Studio ki zaroorat nahi — poora build GitHub Actions (cloud) me hoga,
tumhare phone se bas code push karna hai.

## Ab tak kya kaam karta hai

- Floating round "U" bubble, kisi bhi app ke upar
- Bubble tap karo → chhota command box khulta hai
- **Fixed commands** (turant, bina internet): `open <app>`, `click <text>`,
  `type <text>`, `back`, `home`, `recents`
- **Free-form commands (Step 3, naya)**: kuch bhi apne tareeke se likho,
  jaise *"whatsapp khol ke mummy ko message likho"* ya *"screen par jo
  'skip' likha hai usko dabao"* — jo bhi fixed pattern se match nahi hota,
  woh seedha Claude AI ke paas jata hai jo samajh ke sahi action perform
  karta hai
- Har action ke baad Ultron bolke (TTS, thodi deep/male tone) bata deta hai ki kya kiya
- **Naya (Step 4)**: command box me ab ek 🎤 mic button bhi hai — type karne
  ke bajaye bol ke command de sakte ho, koi alag screen nahi khulti

## Step 3 ka ek-time setup: apni Gemini API key daalo

Free-form commands ke liye ek Google Gemini API key chahiye (yeh alag hai,
isse tum apni khud ki app ko AI se jodte ho):

1. https://aistudio.google.com/apikey par jaake apne Google account se sign
   in karo aur "Create API key" dabao (`AIza...` se shuru hoti hai). Gemini
   ka free tier hai — normal use ke liye bina paisa diye chal jata hai.
2. App kholo → sabse neeche "Gemini API key" wale box me paste karo →
   "API key save karo" dabao. Koi code nahi chhuna — seedha isi screen se.
3. Yeh key sirf tumhare phone ke andar (SharedPreferences me) rehti hai —
   kabhi GitHub/code me nahi jaati, kabhi kisi aur ko nahi dikhti.

Agar key na daalo to bhi Step 2 wale fixed commands kaam karte rahenge —
sirf free-form samajhna AI se hoga.

## Phone se build kaise kare (Android Studio ke bina)

1. Yeh saari files apne GitHub repo me daal do — GitHub app/website ke
   "Add file → Upload files" se seedha, terminal ki zaroorat nahi.
2. `main` branch par push hote hi `.github/workflows/build.yml` khud chal
   jayega aur cloud me APK bana dega.
3. Repo ke **Actions** tab me jao → latest run khulega → 2-4 min me neeche
   **Artifacts** me `UltronAI-debug-apk` milega → download karo.
4. Us `.zip` ko extract karo, andar `app-debug.apk` milega — tap karke
   install karo (ek baar "unknown apps install" allow karna padega).
5. App khol ke: chaaron permission-buttons tap karo (overlay →
   accessibility ON → Start Ultron → microphone allow), API key
   daalo/save karo, phir bubble tap karke 🎤 se bol ke try karo.

## Aage ka plan (1 zip baaki)

- **Step 5 — Polish + final APK**: UI polish, proper app icon, permissions
  flow smooth, aur ek signed release APK (debug ke bajaye).
