# Ultron AI — Step 1 + Step 2

Android Studio ki zaroorat nahi — poora build GitHub Actions (cloud) me hoga,
tumhare phone se bas code push karna hai.

## Ab tak kya kaam karta hai

- Floating round "U" bubble, kisi bhi app ke upar
- Bubble tap karo → ek chhota command box khulta hai
- Usme type karo:
  - `open whatsapp` — koi bhi installed app naam se khol dega
  - `click <text>` / `tap <text>` — screen par us text wale button/link ko tap karega
  - `type <kuch text>` — jo bhi text box focus me hai usme likh dega
  - `back`, `home`, `recents` — phone ke navigation buttons jaisa kaam
- Har action ke baad Ultron bolke (TTS) bhi bata dega ki kya kiya
- Bubble drag karke kahin bhi move kar sakte ho

Free-form Hindi/English commands abhi rule-based hai (sirf upar wale patterns
samajhta hai) — asli AI samajh Step 3 me aayega.

## Phone se build kaise kare (Android Studio ke bina)

1. Yeh saari files apne GitHub repo me daal do. Phone se GitHub app ya
   `github.com` website ke "Add file → Upload files" se seedha upload kar
   sakte ho — koi terminal command zaroori nahi.
   - Agar Git command line chahiye to ek mobile app jaise **Termux** ya
     **Working Copy**(iOS) se bhi push kar sakte ho, lekin upload-files
     wala tareeka sabse simple hai.
2. Repo me `main` branch par push hote hi `.github/workflows/build.yml`
   khud chal jayega aur cloud me APK bana dega.
3. GitHub app/website me apne repo ke **Actions** tab me jao → latest run
   khulega → thodi der (2-4 min) me neeche **Artifacts** me
   `UltronAI-debug-apk` milega → download kar lo.
4. Us `.zip` ko phone par extract karo, andar `app-debug.apk` milega —
   usko tap karke install karo ("unknown apps install" allow karna padega
   ek baar).
5. App khol ke teeno permission-buttons tap karo (overlay → accessibility
   ON → Start Ultron), phir bubble tap karke command box try karo.

## Aage ke plan (3 aur zips baaki)

- **Step 3 — AI brain**: command box me jo bhi likho/bolo, woh ek AI model
  ko jayega jo samjhega tumhara asli matlab kya hai (sirf fixed patterns
  nahi), aur usi Step 2 wale automation engine ko commands dega.
- **Step 4 — Voice**: better male TTS + speech-to-text, taaki type kiye
  bina bol ke command de sako.
- **Step 5 — Polish + final APK**: UI polish, proper app icon, permissions
  flow smooth, aur ek signed release APK.
