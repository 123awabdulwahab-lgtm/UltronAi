package com.ultron.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Step 2: the real automation engine.
 *
 * Once the user turns this ON in Settings > Accessibility, Ultron can:
 *  - read what is on screen (find a button/text by its label)
 *  - tap it
 *  - type text into whatever is focused
 *  - press back / go home / open recents
 *  - open any installed app by name
 *
 * A single running instance is kept in `instance` so the floating bubble
 * (a separate Service) can call into it when the user gives a command.
 */
class UltronAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "UltronAccessibility"
        var instance: UltronAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "Ultron Accessibility Service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Nothing needed here for now — we act on-demand (see functions below)
        // rather than reacting to every event, to keep things predictable.
    }

    override fun onInterrupt() {
        Log.d(TAG, "Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    // ---------- Automation primitives ----------

    /** Finds the first on-screen node whose text or content-description
     *  contains [label] (case-insensitive) and taps it. Returns true if found+tapped. */
    fun clickByText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = findNode(root, label)
        return if (target != null) {
            performClickOnNode(target)
        } else {
            false
        }
    }

    /** Types [text] into whatever editable field is currently focused. */
    fun typeIntoFocused(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
        )
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    /** Opens an installed app whose visible name contains [appName]. */
    fun openApp(appName: String): Boolean {
        val pm = packageManager
        val launchIntents = pm.getInstalledApplications(0).mapNotNull { appInfo ->
            val label = pm.getApplicationLabel(appInfo).toString()
            if (label.contains(appName, ignoreCase = true)) {
                pm.getLaunchIntentForPackage(appInfo.packageName)
            } else null
        }
        val intent = launchIntents.firstOrNull() ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return true
    }

    // ---------- Internal helpers ----------

    private fun findNode(root: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val byText = root.findAccessibilityNodeInfosByText(label)
        if (byText.isNotEmpty()) return byText[0]

        // Fallback: walk the tree and check content descriptions too.
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            if (child.contentDescription?.toString()?.contains(label, ignoreCase = true) == true) {
                return child
            }
            val found = findNode(child, label)
            if (found != null) return found
        }
        return null
    }

    private fun performClickOnNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return false
    }
}
