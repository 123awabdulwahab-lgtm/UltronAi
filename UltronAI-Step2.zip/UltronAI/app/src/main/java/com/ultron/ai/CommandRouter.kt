package com.ultron.ai

/**
 * Step 2 command router: simple rule-based parsing, no AI yet (that's Step 3).
 * Understands a handful of English/Hinglish patterns so the automation
 * primitives in UltronAccessibilityService can already be tested end-to-end.
 */
object CommandRouter {

    /** Returns a spoken/shown response describing what Ultron did. */
    fun handle(rawCommand: String): String {
        val service = UltronAccessibilityService.instance
            ?: return "Accessibility permission on nahi hai. Settings me jaake Ultron ko ON karo."

        val cmd = rawCommand.trim().lowercase()

        return when {
            cmd == "back" || cmd.contains("wapas jao") ->
                if (service.pressBack()) "Theek hai, back ja raha hoon" else "Back nahi kar paya"

            cmd == "home" || cmd.contains("home jao") ->
                if (service.pressHome()) "Home screen par ja raha hoon" else "Home nahi kar paya"

            cmd == "recents" || cmd.contains("recent apps") ->
                if (service.openRecents()) "Recent apps khol raha hoon" else "Recents nahi khul paya"

            cmd.startsWith("open ") || cmd.startsWith("khol ") -> {
                val appName = rawCommand.trim().substringAfter(" ").trim()
                if (service.openApp(appName)) "$appName khol raha hoon"
                else "'$appName' naam ka app nahi mila"
            }

            cmd.startsWith("click ") || cmd.startsWith("tap ") || cmd.startsWith("dabao ") -> {
                val label = rawCommand.trim().substringAfter(" ").trim()
                if (service.clickByText(label)) "'$label' par tap kar diya"
                else "'$label' screen par nahi dikha"
            }

            cmd.startsWith("type ") || cmd.startsWith("likho ") -> {
                val text = rawCommand.trim().substringAfter(" ").trim()
                if (service.typeIntoFocused(text)) "Type kar diya: $text"
                else "Koi text box focus me nahi hai"
            }

            else -> "Yeh command abhi samajh nahi paya — Step 3 me AI brain aane ke baad " +
                    "free-form commands bhi samjhega. Abhi try karo: 'open <app>', " +
                    "'click <text>', 'type <text>', 'back', 'home'."
        }
    }
}
