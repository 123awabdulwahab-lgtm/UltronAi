# Ultron AI — Step 1 to 5 (final)

Yeh aakhri zip hai — is project ke saare features isi ek project me hain.
Android Studio ki zaroorat kabhi nahi padi — poora build GitHub Actions
(cloud) me hota hai.

## Poore features (Step 1–5)

1. Floating round "U" bubble, kisi bhi app ke upar — tap karke command box
   kholo, drag karke kahin bhi move karo
2. Real automation engine (Accessibility Service): `open <app>`,
   `click <text>`, `type <text>`, `back`, `home`, `recents`
3. AI brain (Google Gemini) — free-form Hindi/English command samajh ke
   khud sahi action chalata hai, jab fixed pattern match na ho
4. Voice — 🎤 se bol ke command do (speech-to-text), Ultron jawab bhi
   bolke (male-tone TTS) deta hai
5. Polish (is file me naya):
   - Proper adaptive app icon
   - Signed **release APK** (ab debug nahi, ek real releasable build)
   - "Battery optimization free karo" button — background service ko
     phone band na kare, reliably chalta rahe
   - Reboot ke baad bubble apne aap wapas aa jata hai (agar overlay
     permission pehle se di hui hai)

## Setup / build (phone se, bina Android Studio)

1. Saari files apne GitHub repo me daalo (overwrite purani wali) —
   GitHub app/website ke "Add file → Upload files" se.
2. `main` par push hote hi Actions khud APK banayega. Repo ke **Actions**
   tab me jao → latest run → **Artifacts** me `UltronAI-release-apk`
   milega (2-4 min).
3. Zip extract karo, andar `app-release.apk` — tap karke install karo.
   Pehli baar "unknown apps install" allow karna padega.
4. App kholo aur paanchon step order me tap karo:
   1. Overlay permission
   2. Accessibility Service ON (Settings me "Ultron AI" dhundo)
   3. Start Ultron
   4. Microphone permission
   5. Battery optimization free
5. Neeche apni **Gemini API key** daalo (https://aistudio.google.com/apikey
   se free key banao) → save karo.
6. Bubble tap karo, type ya 🎤 se bolke try karo.

## Ek zaroori baat signing key ke baare me

Isi zip me `app/keystore/ultron-release.jks` bhi hai — isi se APK sign
hota hai (password: `ultron123`, alias: `ultron`). Isse Android ko future
updates install karne dete waqt "same app hai" pata chalta hai. Yeh
tumhare personal use ke liye theek hai; agar kabhi yeh app public/Play
Store par daalni ho to naya, private keystore banana behtar rahega jise
tum kisi ke saath share na karo.

## Aage kya

Jab bhi koi naya feature chahiye ho (naya command, better UI, kisi
specific app ka automation, waghera) — bas bata dena, isi project me jod
denge. Yeh ab ek chalta-phirta base hai, "Step" khatam nahi hote, bas
aage badhte rehte hain.
