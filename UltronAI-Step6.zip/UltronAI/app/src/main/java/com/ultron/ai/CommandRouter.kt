package com.ultron.ai

import android.content.Context

/**
 * Step 2 rule-based patterns are tried first (instant, no network, no cost).
 * Anything that doesn't match falls through to the AI brain, which turns
 * free-form commands — including compound ones like "ammi ko bolo ki main
 * aa raha hoon" (Step 6) — into one of the same underlying actions.
 */
object CommandRouter {

    /** [onResult] is called with the reply to show/speak. May be called on a
     *  background thread (AI brain / WhatsApp automation) — the caller must
     *  hop back to the main thread before touching any UI. */
    fun handle(context: Context, rawCommand: String, onResult: (String) -> Unit) {
        val service = UltronAccessibilityService.instance
        if (service == null) {
            onResult("Accessibility permission on nahi hai. Settings me jaake Ultron ko ON karo.")
            return
        }

        val ruleBasedResult = tryRuleBased(service, rawCommand, onResult)
        if (ruleBasedResult) return

        val apiKey = ApiKeyStore.get(context)
        if (apiKey.isNullOrBlank()) {
            onResult(
                "Yeh command samajh nahi paya. AI brain use karne ke liye MainActivity " +
                "me apni Gemini API key daalo (Step 3 setup)."
            )
            return
        }

        AiBrain.interpret(
            command = rawCommand,
            apiKey = apiKey,
            onResult = { action, value, contact -> execute(service, action, value, contact, onResult) },
            onError = { onResult(it) }
        )
    }

    /** Returns true if a fixed pattern matched (and already called onResult). */
    private fun tryRuleBased(service: UltronAccessibilityService, rawCommand: String, onResult: (String) -> Unit): Boolean {
        val cmd = rawCommand.trim().lowercase()
        when {
            cmd == "back" || cmd.contains("wapas jao") -> execute(service, "back", null, null, onResult)
            cmd == "home" || cmd.contains("home jao") -> execute(service, "home", null, null, onResult)
            cmd == "recents" || cmd.contains("recent apps") -> execute(service, "recents", null, null, onResult)
            cmd.startsWith("open ") || cmd.startsWith("khol ") ->
                execute(service, "open", rawCommand.trim().substringAfter(" ").trim(), null, onResult)
            cmd.startsWith("click ") || cmd.startsWith("tap ") || cmd.startsWith("dabao ") ->
                execute(service, "click", rawCommand.trim().substringAfter(" ").trim(), null, onResult)
            cmd.startsWith("type ") || cmd.startsWith("likho ") ->
                execute(service, "type", rawCommand.trim().substringAfter(" ").trim(), null, onResult)
            else -> return false
        }
        return true
    }

    /** Shared by both the rule-based path and the AI-brain path, so both
     *  ultimately call the same automation primitives the same way. */
    private fun execute(
        service: UltronAccessibilityService,
        action: String,
        value: String?,
        contact: String?,
        onResult: (String) -> Unit
    ) {
        when (action) {
            "back" -> onResult(if (service.pressBack()) "Theek hai, back ja raha hoon" else "Back nahi kar paya")
            "home" -> onResult(if (service.pressHome()) "Home screen par ja raha hoon" else "Home nahi kar paya")
            "recents" -> onResult(if (service.openRecents()) "Recent apps khol raha hoon" else "Recents nahi khul paya")
            "open" -> {
                val app = value ?: return onResult("Kaunsa app, yeh nahi bataya")
                onResult(if (service.openApp(app)) "$app khol raha hoon" else "'$app' naam ka app nahi mila")
            }
            "click" -> {
                val label = value ?: return onResult("Kis par click karna hai, yeh nahi bataya")
                onResult(if (service.clickByText(label)) "'$label' par tap kar diya" else "'$label' screen par nahi dikha")
            }
            "type" -> {
                val text = value ?: return onResult("Kya type karna hai, yeh nahi bataya")
                onResult(if (service.typeIntoFocused(text)) "Type kar diya: $text" else "Koi text box focus me nahi hai")
            }
            "message" -> {
                val who = contact ?: return onResult("Kisko message karna hai, yeh nahi bataya")
                if (value.isNullOrBlank()) {
                    onResult("$who ko kya likhna hai? Poori command ek saath bolo, jaise '$who ko bolo main aa raha hoon'")
                } else {
                    // Async: this involves opening WhatsApp and waiting for screens
                    // to load, so it reports its own result once done.
                    service.sendWhatsAppMessage(who, value, onResult)
                }
            }
            "speak" -> onResult(value ?: "Ji boss?")
            else -> onResult("Yeh action samajh nahi paya: $action")
        }
    }
}
