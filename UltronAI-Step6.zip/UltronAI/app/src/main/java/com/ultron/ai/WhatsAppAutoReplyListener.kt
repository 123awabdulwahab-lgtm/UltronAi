package com.ultron.ai

import android.app.Notification
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * Step 6: WhatsApp auto-reply.
 *
 * The user must turn "Notification access" ON for Ultron in Settings once
 * (MainActivity has a button for this). When ON, and the in-app auto-reply
 * switch is also ON, every new WhatsApp message triggers:
 *   incoming message -> AiBrain.generateReply() -> UltronAccessibilityService
 *   opens that exact chat and sends the reply, automatically.
 *
 * Group-summary notifications and Ultron's own outgoing chats are ignored
 * so it doesn't reply to itself in a loop.
 */
class WhatsAppAutoReplyListener : NotificationListenerService() {

    companion object {
        private const val TAG = "UltronAutoReply"
        private const val WHATSAPP_PACKAGE = "com.whatsapp"
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != WHATSAPP_PACKAGE) return
        if (!AutoReplyPrefs.isEnabled(this)) return
        if ((sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val extras = sbn.notification.extras
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val message = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        if (sender.isBlank() || message.isBlank()) return

        val apiKey = ApiKeyStore.get(this)
        if (apiKey.isNullOrBlank()) {
            Log.d(TAG, "Auto-reply on hai par Gemini API key set nahi hai, skip kar raha hoon")
            return
        }
        val aboutMe = AutoReplyPrefs.getAboutMe(this)

        AiBrain.generateReply(
            senderName = sender,
            incomingMessage = message,
            aboutMe = aboutMe,
            apiKey = apiKey,
            onResult = { reply ->
                handler.post {
                    UltronAccessibilityService.instance?.sendWhatsAppMessage(sender, reply) { result ->
                        Log.d(TAG, "Auto-reply to $sender: $result")
                    }
                }
            },
            onError = { err -> Log.d(TAG, "Auto-reply generate nahi ho paya: $err") }
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {}
}

/** Small SharedPreferences wrapper for the auto-reply toggle + user's "about me" note. */
object AutoReplyPrefs {
    private const val PREFS = "ultron_prefs"
    private const val KEY_ENABLED = "auto_reply_enabled"
    private const val KEY_ABOUT_ME = "about_me"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun getAboutMe(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ABOUT_ME, "") ?: ""

    fun setAboutMe(context: Context, text: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ABOUT_ME, text).apply()
    }
}
