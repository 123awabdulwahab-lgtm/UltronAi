package com.ultron.ai

import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * The AI brain — uses Google's Gemini API (free tier available from Google
 * AI Studio, no card needed to start).
 *
 * Two jobs:
 *  1. interpret() — free-form command -> one structured action (Step 3/6),
 *     used when CommandRouter's fixed patterns don't match.
 *  2. generateReply() — Step 6 auto-reply: turns an incoming WhatsApp
 *     message into a short natural reply, written as if the user sent it.
 */
object AiBrain {

    private const val MODEL = "gemini-2.0-flash"
    private fun apiUrl(apiKey: String) =
        "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$apiKey"

    private const val ACTION_SYSTEM_PROMPT = """
You are the command-interpreter brain for "Ultron", an Android on-device
assistant. The user will type a short instruction in Hindi, English, or a
mix of both. Convert it into exactly ONE JSON object (nothing else, no
markdown fences, no explanation) describing the single action to perform:

{"action": "open", "value": "<app name>"}
{"action": "click", "value": "<visible text of the button/link to tap>"}
{"action": "type", "value": "<text to type into the focused field>"}
{"action": "message", "contact": "<person's name as saved in WhatsApp>", "value": "<the message text to send them>"}
{"action": "back"}
{"action": "home"}
{"action": "recents"}
{"action": "speak", "value": "<a short reply, when the user is just chatting and no phone action is needed>"}

Use "message" whenever the user wants a WhatsApp message sent to someone
by name — e.g. "ammi ko bolo mai aa raha hoon" -> {"action":"message","contact":"ammi","value":"Main aa raha hoon"}.
If the user only names a contact with no message content, still use
"message" with an empty "value".

Pick the single best matching action. Reply with ONLY the raw JSON object.
"""

    /** Free-form command -> one structured action. [onResult] runs on a
     *  background thread — hop to the main thread before touching UI. */
    fun interpret(
        command: String,
        apiKey: String,
        onResult: (action: String, value: String?, contact: String?) -> Unit,
        onError: (String) -> Unit
    ) {
        callGemini(ACTION_SYSTEM_PROMPT, command, apiKey, onText = { text ->
            try {
                val cleaned = text.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                val actionJson = JSONObject(cleaned)
                val action = actionJson.getString("action")
                val value = if (actionJson.has("value")) actionJson.getString("value") else null
                val contact = if (actionJson.has("contact")) actionJson.getString("contact") else null
                onResult(action, value, contact)
            } catch (e: Exception) {
                onError("AI ka jawab samajh nahi paya: ${e.message}")
            }
        }, onError = onError)
    }

    /** Step 6 auto-reply: writes a short natural reply to an incoming WhatsApp
     *  message, on the user's behalf. [onResult] runs on a background thread. */
    fun generateReply(
        senderName: String,
        incomingMessage: String,
        aboutMe: String,
        apiKey: String,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val systemPrompt = """
You are ghost-writing a WhatsApp reply on behalf of a phone's owner, whose
own notes about themself are: "$aboutMe"
Someone named "$senderName" just messaged them. Write ONE short, natural
reply (1-2 sentences, same language/script as the incoming message — Hindi,
Hinglish or English). No quotes, no labels, no explanation — just the reply
text itself, ready to send as-is.
"""
        callGemini(systemPrompt, incomingMessage, apiKey, onText = { onResult(it.trim().trim('"')) }, onError = onError)
    }

    /** Shared Gemini call: sends [systemPrompt] + [userText], returns the raw
     *  text of the first response part via [onText] (background thread). */
    private fun callGemini(
        systemPrompt: String,
        userText: String,
        apiKey: String,
        onText: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        Thread {
            try {
                val url = URL(apiUrl(apiKey))
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("content-type", "application/json")
                conn.doOutput = true

                val body = JSONObject().apply {
                    put("system_instruction", JSONObject().apply {
                        put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
                    })
                    put("contents", JSONArray().put(
                        JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().put(JSONObject().put("text", userText)))
                        }
                    ))
                }

                val os: OutputStream = conn.outputStream
                os.write(body.toString().toByteArray(Charsets.UTF_8))
                os.close()

                val code = conn.responseCode
                if (code !in 200..299) {
                    val err = conn.errorStream?.bufferedReader()?.readText() ?: "HTTP $code"
                    onError("AI se baat nahi ho payi: $err")
                    return@Thread
                }

                val responseText = conn.inputStream.bufferedReader().readText()
                val json = JSONObject(responseText)
                val text = json.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                    .trim()

                onText(text)
            } catch (e: Exception) {
                onError("AI brain me dikkat aayi: ${e.message}")
            }
        }.start()
    }
}
