# Ultron AI — Step 1 to 6

Poora project isi ek repo/zip me hai. Android Studio kabhi nahi chahiye —
build GitHub Actions (cloud) me hota hai.

## Poore features

1. Floating round "U" bubble, kisi bhi app ke upar — tap karke command box,
   drag karke move
2. Automation engine: `open <app>`, `click <text>`, `type <text>`, `back`,
   `home`, `recents`
3. AI brain (Google Gemini) — free-form Hindi/English command samajhta hai
4. Voice — 🎤 se bolke command do, Ultron bolke jawab bhi deta hai
5. Signed release APK, battery-optimization-free, reboot ke baad khud start
6. **Naya — WhatsApp automation**:
   - Ek hi line me poora kaam: *"ammi ko bolo main aa raha hoon"* bologe to
     Ultron khud WhatsApp kholega, "ammi" contact dhundega, message type
     karke **bhej dega** — beech me kuch aur nahi karna padega
   - **Auto-reply**: switch ON karne par, WhatsApp par jo bhi naya message
     aayega, Ultron khud AI se ek chhota jawab bana ke us bande ko bhej
     dega — bina tumhe kuch karna pade

## Step 6 ka setup (do naye kaam)

1. App kholo → button **"6. Notification access allow karo"** dabao →
   list me "Ultron AI" dhundo, ON karo. (Yeh WhatsApp ke naye messages
   padhne ke liye zaroori hai, sirf tabhi jab tum switch ON karo.)
2. Neeche **"WhatsApp par khud jawab de"** switch hai — ON karoge tabhi
   auto-reply chalega, band karna ho to yahi se OFF kar sakte ho.
3. Uske neeche ek chhota box hai — apne baare me 1-2 line likho (jaise
   "Main college me hoon, abhi busy rehta hoon, shaam ko free hota hoon").
   Ultron isi note ko dekh ke reply likhega — yeh sirf tumhare phone me
   save hota hai.

## Ek zaroori, seedhi baat

- **"Meri har jaankari ho"** — is version me Ultron literally tumhari
  "har" jaankari nahi rakhta. Usko bas woh pata hai jo (a) tum us chhote
  "about me" note me likhte ho, aur (b) jo screen par live dikh raha hai
  jab woh koi action kar raha ho. Agar aage chalke usko contacts, calendar,
  ya kisi aur specific cheez ki jaankari chahiye, bata dena — wahi jod
  denge, general "sab kuch de do" karne se AI galat/ajeeb reply bhi de
  sakta hai, isliye step-by-step jod rahe hain.
- **Auto-reply ka ek risk**: jisko bhi jawab jayega, use pata nahi chalega
  ki reply AI ne bheja hai, tumne nahi. Kabhi-kabhi jawab galat/ajeeb bhi
  ho sakta hai (khaaskar family/important logon ke liye). Suggestion:
  pehle 1-2 din khud dekh lena kaisi replies aa rahi hain, phir bharosa
  karna.
- WhatsApp automation timing-based hai (app khulne, chat khulne ka wait
  karta hai) — thoda slow phone ho ya WhatsApp update ho jaye to kabhi
  kabhi timing miss ho sakti hai. Aisa ho to bata dena, delays adjust kar
  denge.

## Build kaise kare (phone se, bina Android Studio)

1. Saari files apne GitHub repo me daalo (overwrite purani wali).
2. `main` par push → Actions tab me build chalega (2-4 min) → Artifacts
   me `UltronAI-release-apk` milega.
3. Zip extract karo, `app-release.apk` install karo.
4. Chhe permission-buttons tap karo (order me), Gemini API key daalo,
   phir Step 6 wala setup (upar) karo.

## Aage kya

Jab bhi naya feature chahiye ho, bata dena — isi project me jodte rahenge.
