package com.ultron.ai

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * Step 1 stub. Once the user turns this ON in Settings > Accessibility,
 * Ultron is allowed to read screen content and (in a later step) perform
 * taps/typing/gestures on the user's behalf inside other apps.
 *
 * Nothing is automated yet — this only proves the service is registered
 * and connected, and logs events so we can build the real automation
 * engine on top of it in the next step.
 */
class UltronAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Step 2+ will inspect event.source / packageName here and let
        // Ultron act on whatever app is currently on screen.
        Log.d("UltronAccessibility", "Event: ${event?.eventType} from ${event?.packageName}")
    }

    override fun onInterrupt() {
        Log.d("UltronAccessibility", "Service interrupted")
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d("UltronAccessibility", "Ultron Accessibility Service connected")
    }
}
