package com.ultron.ai

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * Step 1: a floating round "Ultron" icon that sits on top of every app.
 * Tapping it greets the user out loud. Dragging it moves it around the screen.
 * Real "understand the task and act on other apps" logic comes in a later step,
 * once the accessibility service (Step 2/3) is wired up to this bubble.
 */
class FloatingBubbleService : Service(), TextToSpeech.OnInitListener {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var tts: TextToSpeech? = null

    private val CHANNEL_ID = "ultron_bubble_channel"
    private val NOTIF_ID = 1001

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        startForeground(NOTIF_ID, buildNotification())
        showBubble()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            // Prefer a male-sounding voice if the device exposes one.
            tts?.voices?.firstOrNull { v ->
                v.name.contains("male", ignoreCase = true) && !v.isNetworkConnectionRequired
            }?.let { tts?.voice = it }
        }
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Ultron AI running", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Ultron AI")
            .setContentText("Running in the background")
            .setSmallIcon(android.R.drawable.ic_menu_myplaces)
            .setOngoing(true)
            .build()
    }

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        bubbleView = LayoutInflater.from(this).inflate(R.layout.floating_bubble, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 300

        windowManager.addView(bubbleView, params)

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDrag = false

        bubbleView?.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDrag = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) isDrag = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(bubbleView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDrag) onBubbleTapped()
                    true
                }
                else -> false
            }
        }
    }

    private fun onBubbleTapped() {
        val greeting = "Hello boss"
        Toast.makeText(this, "Ultron: $greeting. Kya hukum hai?", Toast.LENGTH_SHORT).show()
        tts?.speak(greeting, TextToSpeech.QUEUE_FLUSH, null, "ultron_greet")
        // TODO (later step): open a small command box here so the user can type/speak
        // the task, then hand it off to the automation engine (accessibility service).
    }

    override fun onDestroy() {
        super.onDestroy()
        bubbleView?.let { windowManager.removeView(it) }
        tts?.stop()
        tts?.shutdown()
    }
}
