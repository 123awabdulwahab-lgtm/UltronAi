# Ultron AI — Step 1 (foundation)

Yeh project ka pehla zip hai. Isme Android Studio project ka base structure hai:

- Floating round "U" bubble jo kisi bhi app ke upar overlay hoke dikhta hai
- Bubble ko tap karo → "Hello boss" bolta hai (text-to-speech se, male voice try karta hai)
- Bubble ko drag karke screen par kahin bhi move kar sakte ho
- Background me foreground service ke through chalta rehta hai
- Accessibility Service ka stub register ho gaya hai (abhi sirf events log karta hai — real automation Step 2 me aayega)
- MainActivity me teen buttons: overlay permission, accessibility permission, aur bubble start karne ke liye

## Setup kaise kare

1. Android Studio (latest, Hedgehog ya naya) install karo agar nahi hai.
2. `UltronAI` folder ko **File > Open** se Android Studio me kholo. Gradle sync khud ho jayega aur missing `gradlew` wrapper bhi khud generate ho jayega — isliye is zip me wrapper jar nahi bheja.
3. Ek Android phone/emulator connect karo (minSdk 26, yaani Android 8+).
4. Run karo. App khulega, 3 buttons dikhenge — order me tap karo:
   1. Overlay permission allow karo
   2. Settings me "Ultron AI" accessibility service ON karo
   3. "Start Ultron" — floating bubble screen par aa jayega

5. GitHub par isko push karne ke liye:
   ```
   cd UltronAI
   git init
   git add .
   git commit -m "Step 1: floating bubble + accessibility stub"
   git branch -M main
   git remote add origin <tumhara-repo-url>
   git push -u origin main
   ```

## Aage ke 4 zip files ka plan

- **Step 2 — Automation engine**: Accessibility service ko real banayenge — screen padhna, tap/type/swipe perform karna, taaki Ultron kisi bhi app ko chala sake.
- **Step 3 — Brain / AI backend**: Bubble tap karne par ek chhota command box khulega (type ya bolke), jo Claude/GPT jaisa AI model call karega task samajhne ke liye, aur Step 2 ke automation ko commands dega.
- **Step 4 — Voice**: Better male TTS voice + speech-to-text, taaki bina type kiye bol ke kaam de sako, aur Ultron bol ke jawab de.
- **Step 5 — Polish + APK**: UI polish, app icon, permissions flow smooth karna, aur signed release APK banana jo phone par directly install ho sake.

Har step apne aap me chalne wala rahega — isliye abhi bhi yeh Step 1 build ho ke chal jayega, chahe baaki steps baad me aayein.
